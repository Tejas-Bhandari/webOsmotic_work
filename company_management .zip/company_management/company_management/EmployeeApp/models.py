from django.db import models

class Employee(models.Model):
    EmployeeId = models.AutoField(primary_key = True)
    EmployeeName = models.CharField(max_length = 500)
    EmployeeEmail = models.EmailField(max_length = 100, unique = True)

