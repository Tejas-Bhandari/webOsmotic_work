def Name():
    print("Hello")
    f = open('Desktop/tes.txt', 'w')
    f.close()